package Mod;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class LoginController implements Initializable {
    public LoginModel loginModel= new LoginModel();
    @FXML
    private Label isConnected;
    @FXML
    private Label msg;
    @FXML
    private TextField txtUsername;
    @FXML
    private TextField txtPassword;
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        if(loginModel.isDbConnected()){
            isConnected.setText("Welcome To SAS");
        }
        else
            isConnected.setText("Not Connected");
    }
    public void Login(ActionEvent event){
        try {
            if(loginModel.isLogin(txtUsername.getText(),txtPassword.getText())){
                //isConnected.setText("Username and password is correct");
                ((Node)event.getSource()).getScene().getWindow().hide();
                Stage primaryStage=new Stage();
                FXMLLoader loader=new FXMLLoader();
                Commodities commodities=new Commodities();

                //Commodities commodities=(Commodities)loader.getController();
                loader.setController(commodities);
                Pane root = loader.load(getClass().getResource("Commodities.fxml"));
                //commodities.getUser(txtUsername.getText());
                primaryStage.setTitle("Manager");
                primaryStage.setScene(new Scene(root));
                primaryStage.show();
            }
            else
                msg.setText("Username and password is wrong");
        } catch (SQLException throwables) {
            msg.setText("Username and password is wrong");
            throwables.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void Exit(ActionEvent event){
        System.exit(0);
    }
}
